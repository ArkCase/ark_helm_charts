{{- define "arkcase.acme.dir" -}}
/.ssl
{{- end -}}

{{- define "arkcase.acme.env" -}}
  {{- if not (include "arkcase.isRootContext" $) -}}
    {{- fail "The parameter given must be the root context (. or $)" -}}
  {{- end -}}
- name: SSL_DIR
  value: {{ include "arkcase.acme.dir" $ | quote }}
- name: SSL_ENV_FILE
  value: "$(SSL_DIR)/.env"
- name: SSL_TRUSTS_DIR
  value: {{ include "arkcase.trusts.dir" $ | quote }}
- name: ACME_SERVICE_NAME
  value: {{ include "arkcase.service.name" $ | quote }}
{{ include "arkcase.subsystem-access.env" (dict "ctx" $ "subsys" "acme" "key" "url" "name" "ACME_URL") | nindent 0 }}
{{- end -}}

{{- define "arkcase.acme.volumeMount" -}}
  {{- if not (include "arkcase.isRootContext" $) -}}
    {{- fail "The parameter given should be the root context (. or $)" -}}
  {{- end -}}
  {{- include "arkcase.subsystem-access.volumeMount" (dict "ctx" $ "subsys" "acme" "conn" "main" "key" "password" "mountPath" "/.acme.password") -}}
{{- end -}}

{{- define "arkcase.acme.volumeMount-shared" -}}
  {{- include "arkcase.acme.volumeMount" $ | nindent 0 }}
- name: "acme-ssl-vol"
  mountPath: {{ include "arkcase.acme.dir" $ | quote }}
{{- end -}}

{{- define "arkcase.acme.volume" -}}
  {{- if not (include "arkcase.isRootContext" $) -}}
    {{- fail "The parameter given should be the root context (. or $)" -}}
  {{- end -}}
  {{- include "arkcase.subsystem-access.volume" (dict "ctx" $ "subsys" "acme" "conn" "main") -}}
{{- end -}}

{{- define "arkcase.acme.volume-shared" -}}
  {{- include "arkcase.acme.volume" $ | nindent 0 }}
# The shared certificates volume is laughably tiny
- name: "acme-ssl-vol"
  emptyDir:
    medium: "Memory"
    sizeLimit: 4Mi
{{- end -}}
